module.exports = (req, res, next) => {
  const apiKey = req.header('x-api-key');
  const expected = process.env.API_KEY || 'secret-api-key';
  if (!apiKey || apiKey !== expected) {
    const err = new Error('Unauthorized: invalid API key');
    err.statusCode = 401;
    return next(err);
  }
  next();
};