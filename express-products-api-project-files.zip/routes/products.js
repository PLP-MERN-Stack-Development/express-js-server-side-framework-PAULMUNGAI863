const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const productsData = require('../data/productsData');
const auth = require('../middleware/auth');
const validateProduct = require('../middleware/validateProduct');
const asyncHandler = require('../utils/asyncHandler');
const { NotFoundError } = require('../errors/CustomErrors');

router.get('/', asyncHandler(async (req, res) => {
  let results = [...productsData.getAll()];
  if (req.query.q) {
    const q = req.query.q.toLowerCase();
    results = results.filter(p => p.name.toLowerCase().includes(q));
  }
  if (req.query.category) {
    results = results.filter(p => p.category === req.query.category);
  }
  if (req.query.sort) {
    const key = req.query.sort;
    const desc = key.startsWith('-');
    const field = desc ? key.slice(1) : key;
    results.sort((a, b) => (a[field] > b[field] ? 1 : -1));
    if (desc) results.reverse();
  }
  const page = parseInt(req.query.page) || 1;
  const limit = parseInt(req.query.limit) || 10;
  const start = (page - 1) * limit;
  const end = start + limit;
  const paginated = results.slice(start, end);
  res.json({ total: results.length, page, limit, data: paginated });
}));

router.get('/:id', asyncHandler(async (req, res) => {
  const product = productsData.getById(req.params.id);
  if (!product) throw new NotFoundError('Product not found');
  res.json(product);
}));

router.post('/', auth, validateProduct, asyncHandler(async (req, res) => {
  const { name, description, price, category, inStock } = req.body;
  const newProduct = {
    id: uuidv4(),
    name,
    description,
    price: Number(price),
    category,
    inStock: Boolean(inStock)
  };
  productsData.create(newProduct);
  res.status(201).json(newProduct);
}));

router.put('/:id', auth, validateProduct, asyncHandler(async (req, res) => {
  const existing = productsData.getById(req.params.id);
  if (!existing) throw new NotFoundError('Product not found');
  const updates = req.body;
  const updated = productsData.update(req.params.id, updates);
  res.json(updated);
}));

router.delete('/:id', auth, asyncHandler(async (req, res) => {
  const existing = productsData.getById(req.params.id);
  if (!existing) throw new NotFoundError('Product not found');
  productsData.remove(req.params.id);
  res.status(204).send();
}));

router.get('/stats', asyncHandler(async (req, res) => {
  const all = productsData.getAll();
  const counts = {};
  all.forEach(p => {
    counts[p.category] = (counts[p.category] || 0) + 1;
  });
  res.json({ total: all.length, counts });
}));

module.exports = router;