const products = [
  {
    id: '1',
    name: 'USB Cable',
    description: 'A durable USB-C cable',
    price: 7.99,
    category: 'accessories',
    inStock: true
  },
  {
    id: '2',
    name: 'Wireless Mouse',
    description: 'Ergonomic wireless mouse',
    price: 19.5,
    category: 'electronics',
    inStock: true
  }
];

module.exports = {
  getAll: () => products,
  getById: id => products.find(p => p.id === id),
  create: product => products.push(product),
  update: (id, updates) => {
    const idx = products.findIndex(p => p.id === id);
    if (idx === -1) return null;
    products[idx] = { ...products[idx], ...updates };
    return products[idx];
  },
  remove: id => {
    const idx = products.findIndex(p => p.id === id);
    if (idx === -1) return false;
    products.splice(idx, 1);
    return true;
  }
};