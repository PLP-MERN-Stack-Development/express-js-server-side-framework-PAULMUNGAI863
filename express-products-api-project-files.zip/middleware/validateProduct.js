const { ValidationError } = require('../errors/CustomErrors');

module.exports = (req, res, next) => {
  const { name, description, price, category, inStock } = req.body;
  const errors = [];
  if (typeof name !== 'string' || name.trim().length < 2) errors.push('name must be at least 2 characters');
  if (typeof description !== 'string' || description.trim().length === 0) errors.push('description is required');
  if (isNaN(Number(price)) || Number(price) < 0) errors.push('price must be a non-negative number');
  if (typeof category !== 'string' || category.trim().length === 0) errors.push('category is required');
  if (typeof inStock !== 'boolean' && typeof inStock !== 'undefined') errors.push('inStock must be boolean');
  if (errors.length > 0) return next(new ValidationError(errors.join(', ')));
  next();
};